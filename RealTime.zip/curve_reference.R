# Reference for Blowing Pressure Curve
# October 1, 2021
# JH Kim

# Loading the required packages
library(easypackages)
libraries(c('dplyr', 'magrittr', 'tidyr', 'caret', 'readxl',
            'ggplot2', 'tibble'))

# Setting up environments
Sys.setenv(LANG = 'en')
theme_set(new = theme_minimal())
setwd('D:/RTM_PF2/RealTime/')

# Importing the dataset
raw <- read_excel(list.files('.', pattern = 'curve'))
raw %>% head() %>% str()
df <- raw[ , -c(1:6, 10, 14:15, 39:45, 51:61, 63:64)]
colnames(df) <- c('Lot_ID', 'Date', 'Viscosity', 'React.Time', 'React.Temp',
                  'Thickness', 'Resin', 'Hardener', 'Blower', 'Plasticizer', 
                  'Coal', 'Resin.Temp', 'Hanrdener.Temp', 'Blower.Temp',
                  'Speed', 'U.Temp', 'L.Temp',
                  'Pressure1', 'Pressure2', 'Pressure3',
                  'Pressure4', 'Pressure5', 'Pressure6',
                  'Pressure7', 'Pressure8', 'Pressure9',
                  'Pressure10', 'Pressure11', 'Conductivity','ShrinkageL', 'ShrinkageW',
                  'Peel.Strength1', 'Peel.Strength2', 'Peel.Strength3', 'Tissue.Type', 
                  'Length')

# Preprocessing
## Removing NAs
apply(df, 2, function(x) table(sum(is.na(x))))
df <- na.omit(df)
table(is.na(df))

## Making CTQs Tidy
### Shrinkage
df$Shrinkage <- apply(df[ , 30:31], 1, mean)
df <- df[ , -c(30:31)]

### Peel Strength
df$Peel.Strength <- apply(df[ , 30:32],1, mean)
df <- df[ , -c(30:32)]

## Encoding Target into Factor
df$Conductivity <- case_when(
  df$Conductivity >= 0.0200 ~ 'Bad',
  df$Conductivity < 0.0200 ~ 'Good',
  TRUE ~ 'NA')

## Feature Selection
df %<>% select(6, 18:29) %>% filter(Conductivity == 'Good')

## Reference pressure
reference <- df %>% group_by(Thickness) %>% 
  summarise(Pressure1 = mean(Pressure1),
            Pressure2 = mean(Pressure2),
            Pressure3 = mean(Pressure3),
            Pressure4 = mean(Pressure4),
            Pressure5 = mean(Pressure5),
            Pressure6 = mean(Pressure6),
            Pressure7 = mean(Pressure7),
            Pressure8 = mean(Pressure8),
            Pressure9 = mean(Pressure9),
            Pressure10 = mean(Pressure10),
            Pressure11 = mean(Pressure11))

## Handling Outliers
for(i in 1:11){
  for(j in 2:4){
    if(reference[i, j] < 0){
      reference[i, j] <- 0
    }else{reference[i, j]}
  }
}

## Saving the reference file
reference <- reference %>% gather(-Thickness, key = 'var', value = 'value')
reference$var <- substring(reference$var, 9)
write.csv(reference, 'D:/RTM_PF2/RealTime/curve_reference.csv')



