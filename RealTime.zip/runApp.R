library(shiny)
Sys.setenv(LANG = 'en')

runApp(appDir = 'D:/RTM_PF2/RealTime/real_time_dashboard_v02.R',
       port = getOption("shiny.port", 61),
       launch.browser = getOption("shiny.launch.browser",
                                  interactive()),
       host = getOption("shiny.host",
                        "0.0.0.0"),
       workerId = "",
       quiet = FALSE,
       display.mode = c("auto",
                        "normal",
                        "showcase"),
       test.mode = getOption("shiny.testmode",
                             FALSE))


