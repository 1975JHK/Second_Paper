# Real Time Prediction with MES
# September 28, 2021
# JH Kim


# Loading the required Package
library(easypackages)
libraries(c('tidyverse', 'readxl', 'caret', 'see', 'corrplot',
            'correlation', 'ggraph', 'ggplot2', 'e1071', 'DT',
            'DDoutlier', 'magrittr'))

# Setting up environments
getwd()
setwd("D:/RTM_PF2")
Sys.setenv(LANGUAGE = 'en')

# Importing the dataset
raw <- read_excel('D:/RTM_PF2/RealTime/raw_data.xlsx')
str(raw)

# Preprocessing ��
## Extracting 2nd Plat Data from Raw Dataset
raw <- raw %>% filter(�����ڵ� == 'P2')

## Feature Selection
df <- raw[ , -c(1:6, 10, 14:15, 39:45, 51:61, 63:64)]
colnames(df) <- c('Lot_ID', 'Date', 'Viscosity', 'React.Time', 'React.Temp',
                  'Thickness', 'Resin', 'Hardener', 'Blower', 'Plasticizer', 
                  'Coal', 'Resin.Temp', 'Hanrdener.Temp', 'Blower.Temp',
                  'Speed', 'U.Temp', 'L.Temp',
                  'Pressure1', 'Pressure2', 'Pressure3',
                  'Pressure4', 'Pressure5', 'Pressure6',
                  'Pressure7', 'Pressure8', 'Pressure9',
                  'Pressure10', 'Pressure11', 'Conductivity','ShrinkageL', 'ShrinkageW',
                  'Peel.Strength1', 'Peel.Strength2', 'Peel.Strength3', 'Tissue.Type', 
                  'Length')


## Handling the Not Availables
apply(df, 2, function(x) sum(is.na(x)))
df <- na.omit(df)

## Remove Lot Length
df <- df[ , -36]

## Removing features with zero variance 
# df.nvz <- nearZeroVar(df, saveMetrics = F)
# ifelse(length(df.nvz) > 0, df <- df[ , -df.nvz], df)


## Separating the dates
df <- df %>% separate(Date, into = c('Year', 'Month', 'Day'), sep = '/')
df <- df %>% filter(!c(Month %in% c('01', '02', '03', '11', '12') & Year == '20'))
df <- df %>% filter(!c(Month %in% c('01', '02') & Year == '21'))

with(df, table(Year, Month))


## Encoding on Tissue.Type
df$Tissue.Type <- factor(df$Tissue.Type)

## CTQ ����
### Shrinkage
df <- df %>% filter(apply(df[ , 32:33], 1, sd) < 0.12)
df$Shrinkage <- apply(df[ , 32:33], 1, mean)
df <- df[ , -c(32:33)]

### Peel.Strength (will be removed for a while)
df <- df[ , -c(32:34)]
df <- df[ , c(1:30, 32, 31, 33)]

## Removing outliers
### CTQs
df <- df %>% filter(Shrinkage > -2.0 & Shrinkage < -0.1)
df <- df %>% filter(Conductivity > 0.0170, Conductivity < 0.021)

### React.Time
df <- df %>% filter(React.Time > 10, React.Time < 50)

### React.Temp
df <- df %>% filter(React.Temp > 50, React.Temp < 150)

### Line Speed
df <- df %>% filter(Speed > 3.0)

### Upper and Lower Dryer Temp
df <- df %>% filter(U.Temp > 45 & U.Temp < 70)
df <- df %>% filter(L.Temp > 45 & L.Temp < 70)

### Pressure2
df <- df %>% filter(Pressure2 < 10)

### Pressure3
df <- df %>% filter(Pressure3 < 10)

### Pressure4
df <- df %>% filter(Pressure4 < 30)

### Pressure5
df <- df %>% filter(Pressure5 > 0)

### Pressure6
df <- df %>% filter(Pressure6 > 5)

### Pressure7
df <- df %>% filter(Pressure7 > 10)

### Pressure8
df <- df %>% filter(Pressure8 > 20)

### Pressure9
df <- df %>% filter(Pressure9 > 10)

### Pressure10
df <- df %>% filter(Pressure10 > 10)

### Pressure11
df <- df %>% filter(Pressure11 > 5 & Pressure11 < 40)

### Blower
df <- df %>% filter(Blower < 12)

### Viscosity
df <- df %>% filter(Viscosity > 10000 & Viscosity < 50000)

# Feature Engineering
## Pressure slope on Dryers
df <- df %>% mutate(P1 = Pressure6 - Pressure4,
                    P2 = Pressure8 - Pressure6,
                    P3 = Pressure8 - Pressure11)


## Arranging dataset
colnames(df)
df <- df[ , -c(12:13, 15:16)]
df <- df[ , c(1:27,30:32, 28:29)]
colnames(df)


# Preprocessing ��
## Encoding for Changing Numeric type to Categorical type
### Conductivity
df <- df %>% mutate(
  Conductivity = case_when(
    Conductivity < 0.0201 ~ 'Good',
    Conductivity >= 0.0201 ~ 'Bad',
    TRUE ~ 'NA'))

df$Conductivity <- factor(df$Conductivity,
                          levels = c('Good', 'Bad'),
                          labels = c('Good', 'Bad'))

### Shrinkage
df$Shrinkage <- case_when(df$Shrinkage < -0.70 ~ 'Normal',
                          df$Shrinkage < 0.00 ~ 'Good',
                          TRUE ~ 'NA')

df$Shrinkage <- factor(df$Shrinkage,
                       levels = c('Normal', 'Good'),
                       labels = c('Normal', 'Good'))


### Encoding : Tissue.Type
addmargins(table(df$Tissue.Type))
df$Tissue.Type <- as.numeric(df$Tissue.Type)
addmargins(table(df$Tissue.Type))
table(is.na(df))
df <- na.omit(df)            


## Feature Selection
df <- df[ , -c(1:4)]
colnames(df)


# Predictive Model For Conductivity ---------------------------------------
## Rebalancing the dataset with SMOTE
df1 <- ROSE::ROSE(Conductivity ~ ., data = df[ , 1:27])$data

## Splitting the dataset into train and test set
set.seed(46)
index1 <- sample(1:nrow(df1), nrow(df1)*0.75, replace = F)
train1 <- df1[index1, ]
test1 <- df1[-index1, ]

train.origin1 <- train1
test.origin1 <- test1

## Scaling Features
center1 = apply(train1[ , 1:26], 2, mean)
scale1 = apply(train1[ , 1:26], 2, sd)
train1[ , -c(27:28)] <- scale(train1[ , -c(27:28)], center = center1, scale = scale1)
test1[ , -c(27:28)] <- scale(test1[ , -c(27:28)], center = center1, scale = scale1)
head(train1, 3)
head(test1, 3)
dim(train1)
dim(test1)

# Hyper-Parameters Optimization
type = 'C-classification'
kernel = c('radial', 'polynomial')
cost = seq(1.0, 10.0, by = 1.0)
gamma = seq(0.01, 0.1, by = 0.01)
epsilon = seq(0.01, 0.1, by = 0.01)
doe = expand.grid(kernel, cost, gamma, epsilon) %>% rename('kernel' = Var1, 
                                                           'cost' = Var2,
                                                           'gamma' = Var3,
                                                           'epsilon' = Var4)
kappa <- rep(NA, times = 2000)
accuracy <- rep(NA, times = 2000)
table <- cbind(doe, kappa, accuracy)


for(i in 1:2000){
  model1 <<- svm(Conductivity ~ ., data = train1[ , 1:27],
              type = type,
              kernel = table[i, 1],
              cost = table[i, 2],
              gamma = table[i, 3],
              epsilon = table[i, 4],
              probability = T)
  
  y_pred = predict(model1, newdata = test1[ , 1:26])
  cm = confusionMatrix(test1$Conductivity, y_pred)
  table[i, 5] <- cm$overall[2]
  table[i, 6] <- cm$overall[1]
}

table <- table %>% mutate(score = kappa * accuracy)
table[ ,c(5:7)] <- format(round(table[ , c(5:7)], 2) , nsmall = 2)
best <- table[which.max(table$score), ]
cat('Results on Hyper-Parameter Optimization Simulation')
datatable(table)
cat('\n Best Hyper-Parameters \n')
best


# Predictive Model For Shrinkage ---------------------------------------
## Rebalancing the dataset with SMOTE
df2 <- ROSE::ROSE(Shrinkage ~ ., data = df[ , c(1:26, 28)])$data

## Splitting the dataset into train and test set
set.seed(46)
index2 <- sample(1:nrow(df2), nrow(df2)*0.75, replace = F)
train2 <- df2[index2, ]
test2 <- df2[-index2, ]

train.origin2 <- train2
test.origin2 <- test2

## Scaling Features
center2 = apply(train2[ , 1:26], 2, mean)
scale2 = apply(train2[ , 1:26], 2, sd)
train2[ , -c(27)] <- scale(train2[ , -c(27)], center = center2, scale = scale2)
test2[ , -c(27)] <- scale(test2[ , -c(27)], center = center2, scale = scale2)
head(train2, 3)
head(test2, 3)
dim(train2)
dim(test2)

# Hyper-Parameters Optimization
type = 'C-classification'
kernel = c('radial', 'polynomial')
cost = seq(1.0, 10.0, by = 1.0)
gamma = seq(0.01, 0.1, by = 0.01)
epsilon = seq(0.01, 0.1, by = 0.01)
doe = expand.grid(kernel, cost, gamma, epsilon) %>% rename('kernel' = Var1, 
                                                           'cost' = Var2,
                                                           'gamma' = Var3,
                                                           'epsilon' = Var4)
kappa <- rep(NA, times = 2000)
accuracy <- rep(NA, times = 2000)
table <- cbind(doe, kappa, accuracy)


for(i in 1:2000){
  model2 <<- svm(Shrinkage ~ ., data = train2[ , c(1:27)],
              type = type,
              kernel = table[i, 1],
              cost = table[i, 2],
              gamma = table[i, 3],
              epsilon = table[i, 4],
              probability = T)
  
  y_pred = predict(model2, newdata = test2[ , 1:26])
  cm = confusionMatrix(test2$Shrinkage, y_pred)
  table[i, 5] <- cm$overall[2]
  table[i, 6] <- cm$overall[1]
}

table$kappa <- as.numeric(table$kappa)
table$accuracy <- as.numeric(table$accuracy)
table2 <- table %>% mutate(score = kappa * accuracy)
table2[ ,c(5:7)] <- format(round(table2[ , c(5:7)], 2) , nsmall = 2)
best2 <- table2[which.max(table2$score), ]
cat('Results on Hyper-Parameter Optimization Simulation')
datatable(table2)
cat('\n Best Hyper-Parameters \n')
best2




real_time_prediction <- function(){
  # Importing the dataset
  raw <- read.csv('mes_new_data.csv')[-1]
  # str(raw)
  
  # Preprocessing
  ## Feature Selection
  df <- raw[ , -c(7:9)] %>% tail(5)
  
  ## Removing NAs
  df <- na.omit(df)
  dim(df)
  
  ## Feature Creation
  df %<>% mutate(P1 = Pressure6 - Pressure4,
                 P2 = Pressure8 - Pressure6,
                 P3 = Pressure8 - Pressure11)
  
  ## Encoding Character Type
  df$Tissue.Type <- as.numeric(factor(df$Tissue.Type))
  
  ## Arranging Features
  df <- df[ , c(1:2, 26, 3:25, 27:29)]
  origin_df <- df[ , c(1:3, 7, 12:25, 27:29)]
  
  ## Prediction for Conductivity------------------------------------------------
  df1 <- df
  df1[ , -c(1:3)] <- scale(df1[ , -c(1:3)], 
                           center = center1, scale = scale1)
  
  ## prediction
  y_pred1 <- predict(model1, newdata = df1[ , 4:29])
  pred_repo1 <- cbind(origin_df, y_pred1) %>% rename(Conductivity = y_pred1)
  
  
  ## Prediction for Shrinkage---------------------------------------------------
  df2 <- df
  df2[ , -c(1:3)] <- scale(df2[ , -c(1:3)], 
                           center = center2, scale = scale2)
  
  ## prediction
  y_pred2 <- predict(model2, newdata = df2[ , 4:29])
  pred_repo2 <- cbind(pred_repo1, y_pred2) %>% rename(Shrinkage = y_pred2)
  
  
  ## prediction for De-lamination-----------------------------------------------
  pred_repo2$Delami <- ifelse(pred_repo2$Thickness >= 160 & 
                                pred_repo2$Pressure4 >= 7.4 & 
                                pred_repo2$Pressure5 >= 9.3, 'Bad', 'Good')
  write.csv(pred_repo2, 'real_time_prediction.csv')
  
}

execute_rtp <- function(interval = 60){
  real_time_prediction()
  message('Complete Real Time Prediction!', Sys.time())
  later::later(execute_rtp, interval)
}

execute_rtp()
