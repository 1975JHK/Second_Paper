setwd('D:/RTM_PF2/')

Sys.setenv(JAVA_HOME="C:/Program Files/Java/jdk1.7.0_80")
library(rJava)
library(RJDBC)
library(DBI)
library(tidyverse)

drv <-JDBC(driverClass="oracle.jdbc.OracleDriver", 
           classPath="D:/App/kimjonghoon/product/11.2.0/client_1/ojdbc6.jar")

conn <-dbConnect(drv,"jdbc:oracle:thin:@//165.244.142.27:1521/LGHSMESP",
                 "EZMES","pfmes_prd1#")

mesdata_extractor <- function(){
  new_data <- dbGetQuery(conn,
                         "
SELECT A.LOTID, A.ACTDTTM
       , NVL((SELECT CLCTVAL01 FROM OQCDATACOLLECT WHERE CLCTITEM = 'LQCC001' AND OQCID IN (SELECT MLOTID FROM LOTMATERIALHISTORY WHERE LOTID = A.LOTID AND STORID Like 'RMX%' AND WIPSEQ = 1)),0) LQCC001
       , NVL((SELECT CLCTVAL01 FROM OQCDATACOLLECT WHERE CLCTITEM = 'LQCC003' AND  OQCID IN (SELECT MLOTID FROM LOTMATERIALHISTORY WHERE LOTID = A.LOTID AND STORID Like 'RMX%' AND WIPSEQ = 1)),0) LQCC003
       , NVL((SELECT CLCTVAL01 FROM OQCDATACOLLECT WHERE CLCTITEM = 'LQCC002' AND OQCID IN (SELECT MLOTID FROM LOTMATERIALHISTORY WHERE LOTID = A.LOTID AND STORID Like 'RMX%' AND WIPSEQ = 1)),0) LQCC002
       , (SELECT S02 FROM PRODUCTATTR WHERE PRODID = (SELECT PRODID FROM LOT WHERE LOTID = A.LOTID)) AS P_THICK -- �β�
       , (SELECT CASE WHEN MTRLID LIKE '%PF312+327%' THEN 'PF312+327'
                      WHEN MTRLID LIKE '%L20+H20%' THEN 'L20+H20'
                      WHEN MTRLID LIKE '%IHKCNH200000000000%' THEN 'H20'
                      WHEN MTRLID LIKE '%IHKCNL200000000000%' THEN 'L20'
                      WHEN MTRLID LIKE '%PF312' OR MTRLID LIKE '%N312%' THEN 'PF311'
                      WHEN MTRLID LIKE '%PF327' OR MTRLID LIKE '%N327%' THEN 'PF327' END
                 FROM LOTMATERIALHISTORY WHERE LOTID = A.LOTID AND STORID Like 'RMX%' AND WIPSEQ = 1) RESN_TYPE
       , (SELECT RESN_RATE1 FROM PF_WORKORDERATTR WOA, LOT L WHERE WOA.WOId = L.WOID AND LOTID = A.LOTID) MIXRATE1
       , (SELECT RESN_RATE2 FROM PF_WORKORDERATTR WOA, LOT L WHERE WOA.WOId = L.WOID AND LOTID = A.LOTID) MIXRATE2
       , A.PHR_VALUE01, A.PHR_VALUE02, A.PHR_VALUE03
       , ROUND((Select AVG(TAG_VALUE) from HIMSUMS.UMS_TBL_DATA_HISTORY Where Tag_UID in ('02:26:15:38') AND TXN_TIME BETWEEN A.ACTDTTM - 1/24/60/6 AND A.ACTDTTM),1) as TMPRESIN
       , A.HARDENING_VALUE01, A.HARDENING_VALUE02, A.HARDENING_VALUE03
       , A.PRESS_VALUE01, A.PRESS_VALUE02, A.PRESS_VALUE03, A.PRESS_VALUE04, A.PRESS_VALUE05, A.PRESS_VALUE06
       , A.PRESS_VALUE07, A.PRESS_VALUE08, A.PRESS_VALUE09, A.PRESS_VALUE10, A.PRESS_VALUE11
       , (SELECT S01 FROM PRODUCTATTR WHERE PRODID = (SELECT PRODID FROM LOT WHERE LOTID = LOTID_RT AND LOTID = A.LOTID )) as PRODTYPE
       , (SELECT S04 FROM PRODUCTATTR WHERE PRODID = (SELECT PRODID FROM LOT WHERE LOTID = A.LOTID)) AS P_LENGTH -- ����
FROM (WITH LOTINFO AS (
      SELECT LOTID, 
             CASE WHEN LOTDTTM_IN < sysdate - 1/24 THEN sysdate - 1/24 ELSE  LOTDTTM_IN END as STRTIME,
             CASE WHEN NVL(LOTDTTM_OT, sysdate) < sysdate THEN LOTDTTM_OT ELSE sysdate END as ENDTIME
       FROM LOT L
      WHERE LOTID = LOTID_RT
      AND LOTID Like 'P2D%'
      AND LOTDTTM_CR > sysdate - 2
      AND NVL(LOTDTTM_OT, sysdate) > sysdate - 1/24 )
      SELECT MIN(LOTID) as LOTID --MIN(STRTIME) as STRTIME, MIN(ENDTIME) as ENDTIME, 
             , TXN_TIME ACTDTTM
             , AVG(PHR_VALUE01) PHR_VALUE01, AVG(PHR_VALUE02) PHR_VALUE02, AVG(PHR_VALUE03) PHR_VALUE03
             , AVG(HARDENING_VALUE01) HARDENING_VALUE01, AVG(HARDENING_VALUE02) HARDENING_VALUE02, AVG(HARDENING_VALUE03) HARDENING_VALUE03
             , AVG(PRESS_VALUE01) PRESS_VALUE01, AVG(PRESS_VALUE02) PRESS_VALUE02, AVG(PRESS_VALUE03) PRESS_VALUE03, AVG(PRESS_VALUE04) PRESS_VALUE04
             , AVG(PRESS_VALUE05) PRESS_VALUE05, AVG(PRESS_VALUE06) PRESS_VALUE06, AVG(PRESS_VALUE07) PRESS_VALUE07, AVG(PRESS_VALUE08) PRESS_VALUE08
             , AVG(PRESS_VALUE09) PRESS_VALUE09, AVG(PRESS_VALUE10) PRESS_VALUE10, AVG(PRESS_VALUE11) PRESS_VALUE11
        FROM LOTINFO L, 
        (SELECT TXN_TIME, 
                ROUND(MAX(PHR_VALUE01),1) as PHR_VALUE01,
                ROUND(MAX(PHR_VALUE02),1) as PHR_VALUE02,
                ROUND(MAX(PHR_VALUE03),1) as PHR_VALUE03,
                ROUND(MAX(HARDENING_VALUE01),3) as HARDENING_VALUE01,
                ROUND((MAX(HARDENING_VALUE02L)+ MAX(HARDENING_VALUE02C)+ MAX(HARDENING_VALUE02R))/3,3) as HARDENING_VALUE02,
                ROUND((MAX(HARDENING_VALUE03L)+ MAX(HARDENING_VALUE03C)+ MAX(HARDENING_VALUE03R))/3,3) as HARDENING_VALUE03,
                ROUND(MAX(PRESS_VALUE01)) as PRESS_VALUE01,
                ROUND(MAX(PRESS_VALUE02)) as PRESS_VALUE02, 
                ROUND(MAX(PRESS_VALUE03)) as PRESS_VALUE03,
                ROUND(MAX(PRESS_VALUE04)) as PRESS_VALUE04,
                ROUND(MAX(PRESS_VALUE05)) as PRESS_VALUE05,
                ROUND(MAX(PRESS_VALUE06)) as PRESS_VALUE06,
                ROUND(MAX(PRESS_VALUE07)) as PRESS_VALUE07,
                ROUND(MAX(PRESS_VALUE08)) as PRESS_VALUE08,
                ROUND(MAX(PRESS_VALUE09)) as PRESS_VALUE09,
                ROUND(MAX(PRESS_VALUE10)) as PRESS_VALUE10,
                ROUND(MAX(PRESS_VALUE11)) as PRESS_VALUE11
          FROM (
        SELECT TXN_TIME
               ,CASE WHEN TAG_UID = '02:26:15:333' THEN TAG_VALUE END as PHR_VALUE01  
               ,CASE WHEN TAG_UID = '02:26:15:334' THEN TAG_VALUE END as PHR_VALUE02 
               ,CASE WHEN TAG_UID = '02:26:15:335' THEN TAG_VALUE END as PHR_VALUE03 
               ,CASE WHEN TAG_UID = '02:26:15:138' THEN TAG_VALUE END as HARDENING_VALUE01  
               ,CASE WHEN TAG_UID = '02:26:15:183' THEN TAG_VALUE END as HARDENING_VALUE02L
               ,CASE WHEN TAG_UID = '02:26:15:184' THEN TAG_VALUE END as HARDENING_VALUE02C
               ,CASE WHEN TAG_UID = '02:26:15:185' THEN TAG_VALUE END as HARDENING_VALUE02R
               ,CASE WHEN TAG_UID = '02:26:15:175' THEN TAG_VALUE END as HARDENING_VALUE03L
               ,CASE WHEN TAG_UID = '02:26:15:176' THEN TAG_VALUE END as HARDENING_VALUE03C
               ,CASE WHEN TAG_UID = '02:26:15:177' THEN TAG_VALUE END as HARDENING_VALUE03R
               ,CASE WHEN TAG_UID = '02:26:15:163' THEN TAG_VALUE / 1000 END as PRESS_VALUE01
               ,CASE WHEN TAG_UID = '02:26:15:164' THEN TAG_VALUE / 1000 END as PRESS_VALUE02
               ,CASE WHEN TAG_UID = '02:26:15:165' THEN TAG_VALUE / 1000 END as PRESS_VALUE03
               ,CASE WHEN TAG_UID = '02:26:15:166' THEN TAG_VALUE / 1000 END as PRESS_VALUE04
               ,CASE WHEN TAG_UID = '02:26:15:167' THEN TAG_VALUE / 1000 END as PRESS_VALUE05
               ,CASE WHEN TAG_UID = '02:26:15:168' THEN TAG_VALUE / 1000 END as PRESS_VALUE06
               ,CASE WHEN TAG_UID = '02:26:15:169' THEN TAG_VALUE / 1000 END as PRESS_VALUE07
               ,CASE WHEN TAG_UID = '02:26:15:170' THEN TAG_VALUE / 1000 END as PRESS_VALUE08
               ,CASE WHEN TAG_UID = '02:26:15:171' THEN TAG_VALUE / 1000 END as PRESS_VALUE09
               ,CASE WHEN TAG_UID = '02:26:15:172' THEN TAG_VALUE / 1000 END as PRESS_VALUE10
               ,CASE WHEN TAG_UID = '02:26:15:173' THEN TAG_VALUE / 1000 END as PRESS_VALUE11  
        FROM (
                  Select TXN_TIME, TAG_UID, TAG_VALUE 
                    from HIMSUMS.UMS_TBL_DATA_HISTORY 
                   Where Tag_UID in ('02:26:15:163','02:26:15:164','02:26:15:165','02:26:15:166','02:26:15:167','02:26:15:168','02:26:15:169','02:26:15:170','02:26:15:171','02:26:15:172','02:26:15:173',
                                     '02:26:15:333','02:26:15:334','02:26:15:335','02:26:15:138','02:26:15:183','02:26:15:184','02:26:15:185','02:26:15:175','02:26:15:176','02:26:15:177'
                                     )  
                      AND TXN_TIME  BETWEEN sysdate - 1/24 AND sysdate 
           )
        )
        GROUP BY TXN_TIME ) PRESS 
      WHERE TXN_TIME BETWEEN STRTIME AND ENDTIME
      GROUP BY TXN_TIME ) A
ORDER BY A.ACTDTTM , A.LOTID 
")
}


mes_data <- function(interval = 120){
  new_data <- mesdata_extractor() %>% data.frame()
  colnames(new_data) <- c('Lot_ID', 'Date', 'Viscosity', 'React.Temp', 'React.Time',
                          'Thickness', 'Resin_Type', 'ResinA_Rate', 'ResinB_Rate',
                          'Resin', 'Hardener', 'Blower', 'Resin.Temp', 'Speed', 
                          'U.Temp', 'L.Temp', 'Pressure1', 'Pressure2', 'Pressure3',
                          'Pressure4', 'Pressure5', 'Pressure6', 'Pressure7', 'Pressure8',
                          'Pressure9', 'Pressure10', 'Pressure11','Tissue.Type', 'Length')
  new_data$Viscosity <- as.numeric(new_data$Viscosity)
  new_data$React.Temp <- as.numeric(new_data$React.Temp)
  new_data$React.Time <- as.numeric(new_data$React.Time)
  new_data$Thickness <- as.numeric(new_data$Thickness)
  new_data$Resin <- as.numeric(new_data$Resin)
  new_data$Hardener <- as.numeric(new_data$Hardener)
  new_data$Blower <- as.numeric(new_data$Blower)
  new_data$Resin.Temp <- as.numeric(new_data$Resin.Temp)
  new_data$Length <- as.numeric(new_data$Length)
  
  message('Compeleted to save MES dataset!', Sys.time())
  write.csv(new_data, 'new_data.csv')
  later::later(mes_data, interval)

}

mes_data()


