# Real Time Prediction with MES
# September 16, 2021
# JH Kim

# Loading the required packages
library(easypackages)
libraries(c('tidyverse', 'readxl', 'caret', 'e1071', 'magrittr'))

# Setting up environments
Sys.setenv(LANG = 'en')
theme_set(new = theme_minimal())
setwd('D:/RTM_PF2/')
options(warn = -1)


real_time_prediction <- function(){
  # Importing the dataset
  raw <- read.csv('mes_new_data.csv')[-1]
  # str(raw)
  
  # Preprocessing
  ## Feature Selection
  df <- raw[ , -c(7:9)] %>% tail(5)
  
  ## Removing NAs
  df <- na.omit(df)
  dim(df)
  
  ## Feature Creation
  df %<>% mutate(P1 = Pressure6 - Pressure4,
                 P2 = Pressure8 - Pressure6,
                 P3 = Pressure8 - Pressure11)
  
  ## Encoding Character Type
  df$Tissue.Type <- as.numeric(factor(df$Tissue.Type))
  
  ## Arranging Features
  df <- df[ , c(1:2, 26, 3:25, 27:29)]
  origin_df <- df[ , c(1:3, 7, 12:25, 27:29)]
  
  ## Scaling Features
  df[ , -c(1:3)] <- scale(df[ , -c(1:3)], 
                          center = center, scale = scale)
  ## modeling for conductivity
  model1 <- svm(Conductivity ~ ., 
               data = train[ , -28],
               type = 'C-classification',
               kernel = best[ , 1],
               cost = best[ , 2],
               gamma = best[ , 3],
               epsilon = best[ , 4])
  
  ## prediction for conductivity
  y_pred1 <- predict(model1, newdata = df[ , 4:29])
  pred_repo1 <- cbind(origin_df, y_pred1) %>% rename(Conductivity = y_pred1)
  # write.csv(pred_repo, 'real_time_prediction.csv')
  
  
  ## modeling for shrinkage
  model2 <- svm(Shrinkage ~ ., 
               data = train[ , -27],
               type = 'C-classification',
               kernel = best2[ , 1],
               cost = best2[ , 2],
               gamma = best2[ , 3],
               epsilon = best2[ , 4])
  
  ## prediction for shrinkage
  y_pred2 <- predict(model2, newdata = df[ , 4:29])
  pred_repo2 <- cbind(pred_repo1, y_pred2) %>% rename(Shrinkage = y_pred2)
  
  
  # prediction for delamination
  pred_repo2$Delami <- ifelse(pred_repo2$Thickness >= 160 & 
                                      pred_repo2$Pressure4 >= 7.4 & 
                                      pred_repo2$Pressure5 >= 9.3, 'Bad', 'Good')
  write.csv(pred_repo2, 'real_time_prediction.csv')
}

execute_rtp <- function(interval = 60){
  real_time_prediction()
  message('Complete Real Time Prediction!', Sys.time())
  later::later(execute_rtp, interval)
}

execute_rtp()
