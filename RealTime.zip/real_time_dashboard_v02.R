# Dashboard for Real Time Prediction
# September 27, 2021
# JH Kim

# Loading the required packages
library(easypackages)
libraries(c('shiny', 'shinythemes', 'ggplot2', 'dplyr',
            'magrittr', 'caret', 'readxl', 'data.table',
            'shinydashboard', 'tidyr', 'forcats'))

# Setting up environments
Sys.setenv(LANG = 'en')
theme_set(new = theme_minimal())
options(warn = -1)
setwd('D:/RTM_PF2/')
reference <- read.csv('D:/RTM_PF2/RealTime/curve_reference.csv')[-1]

# Front End
ui <- dashboardPage(
  # theme = bslib::bs_theme(version = 4, bootswatch = 'sandstone'),
  dashboardHeader(title = 'Real Time Prediction',
                  dropdownMenu(type = 'message',
                               messageItem(from = '김종훈 책임',
                                           message = '실시간 예측 UIX 개발 중',
                                           icon = icon('pencil-alt'), time = '2021-09-27 19:00'),
                               messageItem(from = '김종훈 책임',
                                           message = 'Feed Back은 김종훈 책임에게..',
                                           icon = icon('mobile-alt'), time = '2021-09-27 19:03'))),
  dashboardSidebar(disable = T),
  dashboardBody(
    fluidRow(width = 12,
             column(width = 3, height = 200,
                    valueBoxOutput("lotid", width = '100%'),
                    valueBoxOutput("date", width = '100%'),
                    valueBoxOutput("progress", width = '100%')),
             
             column(width = 9, height = 400,
                    box(title = strong('Report'), width = '100%', height = '100%',
                        collapsible = FALSE, solidHeader = TRUE, status = 'success', 
                        tableOutput('table')))
    ),
    
    br(),
    
    fluidRow(width = 12,
             column(width = 3,
                    box(title = strong('Pressure in Interval'), width = '100%', height = '100%',
                        collapsible = FALSE, solidHeader = TRUE, status = 'success',
                        infoBoxOutput("p1", width = '100%'),
                        br(),
                        infoBoxOutput("p2", width = '100%'),
                        br(),
                        infoBoxOutput("p3", width = '100%'))),
             
             column(width = 9,
                    box(title = strong('Blowing Pressure Curve'), width = '100%', height = '100%',
                        collapsible = FALSE, solidHeader = TRUE, status = 'success', 
                        plotOutput(('plot'), height = 355)))
    )
  )
)


# Back End
server <- function(input, output, session) {
  
  
  # 0. Importing the raw dataset --------------------------------------------
  report <- function(){
    invalidateLater(60000, session)
    raw <- read.csv('D:/RTM_PF2/real_time_prediction.csv')[-1]
    df <- na.omit(raw)
    if(df$Speed < 1.0 | df$Pressure8 < 10){
      df$Conductivity <- 'OOD'
      df$Shrinkage <- 'OOD'
      df$Delami <- 'OOD'}
    return(df)
  }
  
  
  
  # 1. Prediction Report ----------------------------------------------------
  output$table <- renderTable({
    message('Completed the Prediction Report!!', Sys.time())
    report()[ , c(1:7, 22:24)] %>% data.table()
  }, spacing = c('l'), align = c('c'), width = '100%', bordered = T)
  
  
  
  # 2. Pressure Curve -------------------------------------------------------
  output$plot <- renderPlot({
    new_report <- report()[ , 8:18] %>% gather(key = 'var', value = 'value')
    new_report$var <- substring(new_report$var, 9) %>% as.numeric()
    new_report %>% group_by(var) %>% summarize(Ave = mean(value)) %>% 
    ggplot(aes(x = var, y = Ave, fill = as.factor(var), group = 1))+
      geom_line(size = 0.7, color = 'black', alpha = 0.8)+
      geom_point(size = 3, color = 'black', alpha = 0.8, show.legend = F
                 )+
      geom_col(width = 0.6, alpha = 0.8, show.legend = F)+
      geom_line(data = reference %>% filter(Thickness == report()[5 , 4]), 
                aes(x = var, y = value, group = 1), size = 0.7, color = 'red',
                linetype = 2)+
      geom_text(aes(label = round(Ave, 1)), size = 4, vjust = -0.2, fontface = 'bold.italic')+
      scale_x_continuous(breaks = seq(1:11))+
      labs(x = 'Zone', y = 'Pressure')+
      theme(axis.text = element_text(size = 13, face = 'bold'),
            axis.title = element_text(size = 15, face = 'bold'))
  }, res = 98)
  
  
  
  # 3. ValueBoxes --------------------------------------------------------------
  output$lotid <- renderValueBox({
    message('Valuebox 1번이 Update되었습니다!', Sys.time())
    invalidateLater(60000, session)
    report <- report()
    valueBox(value = tags$p(report[1 , 1], style = "font-size: 80%;"),
             strong("Lot_ID"), icon = icon("folder-open"), color = "light-blue")
  })
  
  output$date <- renderValueBox({
    message('Valuebox 2번이 Update되었습니다!', Sys.time())
    invalidateLater(60000, session)
    report <- report()
    valueBox(value = tags$p(report[ , 2] %>% tail(1), style = "font-size: 80%;"),
             strong("Latest Updated"), icon = icon("far fa-clock"), color = "green")
  })
  
  output$progress <- renderValueBox({
    message('Valuebox 3번이 Update되었습니다!', Sys.time())
    invalidateLater(60000, session)
    report <- report()
    progress <- ifelse(report[ , 5] %>% tail(1) > 1.0 & report[ , 15] %>% tail(1) > 20,  'On', 'Off')
    valueBox(value = tags$p(progress, style = "font-size: 80%;"),
             strong("Progress"), icon = icon("fas fa-microchip"), color = "orange")
  })
  
  
  # 4. ValueBoxes -------------------------------------------------------------
  output$p1 <- renderInfoBox({
    infoBox(value = tags$p(mean(report()[ , 19]), style = "font-size: 150%;"),
            strong("P1 = 6Zone - 4Zone"), icon = icon("fas fa-fist-raised"), color = "light-blue")
  })
  
  output$p2 <- renderInfoBox({
    infoBox(value = tags$p(mean(report()[ , 20]), style = "font-size: 150%;"), 
            strong("P2 = 8Zone - 6Zone") , icon = icon("fas fa-hand-scissors"), color = "green")
  })
  
  output$p3 <- renderInfoBox({
    infoBox(value = tags$p(mean(report()[ , 21]), style = "font-size: 150%;"), 
            strong("P3 = 8Zone - 11Zone"), icon = icon("fas fa-hand-paper"), color = "orange")
  })
  
  
  
}

# Running the application
shinyApp(ui = ui, server = server)